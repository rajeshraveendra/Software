#!/bin/bash
systemctl stop mariadb >/dev/null 2>&1
for PROCESSID in $(ps -ef |grep mariadb |grep -v grep|awk -F " " '{print $2}'); do kill -9 $PROCESSID; done >/dev/null 2>&1
rm /var/lib/mysql/mysql.sock >/dev/null 2>&1
rm -f /etc/my.cnf >/dev/null 2>&1
rm -rf /etc/my.cnf.d/ >/dev/null 2>&1
yum remove mariadb* -y >/dev/null 2>&1
yum remove mariadb-libs -y >/dev/null 2>&1
find / -iname 'mysql*' -exec rm -rf {} \; >/dev/null 2>&1
cat /dev/null >/etc/yum.repos.d/MariaDB10.repo
