#!/bin/bash
echo
echo "Cleaning up previous DB setup from this host.."
echo "This will remove MariaDB and all related databases from this host.."
echo "Type \"ProCeEd\" (case sensitive) to continue.."
read reply

if [ $reply != ProCeEd ]
then
	echo "Quiting ....."
	echo
	exit 100
fi
chmod 700 db_uninstall.sh
sh db_uninstall.sh
chmod 600 db_uninstall.sh >/dev/null 2>&1
echo
yum install mariadb-server -y >/dev/null 2>&1
if [ $? -eq 0 ]
then
	echo "Maria DB service has been installed.."
else
	echo "ERROR: Maria DB installation has been failed.."
	exit 1
fi
systemctl start mariadb >/dev/null 2>&1
if [ $? -eq 0 ]
then
	echo "Maria DB service has been started.."
else
	echo "ERROR: Could not start Maria DB.."
	exit 2
fi
systemctl enable mariadb >/dev/null 2>&1

echo "Starting the inital setup of Maria DB.."
#/usr/bin/mysql_secure_installation
chmod 700 db_secure.sh >/dev/null 2>&1
sh db_secure.sh
if [ $? -eq 0 ]
then
	echo
	echo "Maria DB initial setup has been done.."
	echo
	chmod 600 db_secure.sh >/dev/null 2>&1
else
	echo
	echo "ERROR: Maria DB initial setup has been failed.."
	chmod 600 db_secure.sh >/dev/null 2>&1
	echo
	exit 3
fi

RPWD=$(cat rpd.tmp)
rm -f rpd.tmp >/dev/null 2>&1


mysql -uroot -p${RPWD} -e "CREATE DATABASE BOOKLIBRARY /*\!40100 DEFAULT CHARACTER SET utf8 */;" >/dev/null 2>&1
mysql -uroot -p${RPWD} -e "CREATE USER libadmin@localhost IDENTIFIED BY 'Libadmin@345';" >/dev/null 2>&1
mysql -uroot -p${RPWD} -e "GRANT ALL PRIVILEGES ON BOOKLIBRARY.* TO 'libadmin'@'localhost';" >/dev/null 2>&1
mysql -uroot -p${RPWD} -e "GRANT ALL PRIVILEGES ON BOOKLIBRARY.* TO 'libadmin'@'%' IDENTIFIED BY 'Libadmin@345' WITH GRANT OPTION;" >/dev/null 2>&1
mysql -uroot -p${RPWD} -e "FLUSH PRIVILEGES;" >/dev/null 2>&1
mysql -uroot -p${RPWD} -D BOOKLIBRARY -e "CREATE TABLE bookdetails (Book_Code VARCHAR(15) NOT NULL, Location VARCHAR(15) NOT NULL, Book_Name TEXT NOT NULL, Auther_Name TEXT NOT NULL, Year INT(4));" >/dev/null 2>&1

cat table_content |grep -v "Location" |while read LINE
do
BOOKCODE=$(echo $LINE|awk -F ";" '{print $1}')
LOCATION=$(echo $LINE|awk -F ";" '{print $2}')
BOOKNAME=$(echo $LINE|awk -F ";" '{print $3}')
AUTHER=$(echo $LINE|awk -F ";" '{print $4}')
YEAR=$(echo $LINE|awk -F ";" '{print $5}')
mysql -uroot -p${RPWD} -D BOOKLIBRARY -e "INSERT INTO bookdetails (Book_Code, Location, Book_Name, Auther_Name, Year) VALUES ('${BOOKCODE}', '${LOCATION}', '${BOOKNAME}', '${AUTHER}', '${YEAR}');"
done

# Updating MariaDB to 10.6 Version
mysqldump -u root -proot123 --all-databases > /tmp/all-database.sql 2>&1
yum update -y  >/dev/null 2>&1
cat MariaDB10.repo > /etc/yum.repos.d/MariaDB10.repo 2>&1
systemctl stop mariadb >/dev/null 2>&1
yum remove mariadb-server mariadb mariadb-libs -y >/dev/null 2>&1
yum clean all >/dev/null 2>&1
yum -y install MariaDB-server MariaDB-client >/dev/null 2>&1
systemctl enable mariadb >/dev/null 2>&1
systemctl start mariadb >/dev/null 2>&1
mysql_upgrade -uroot -p${RPWD} >/dev/null 2>&1

echo "DB Name          : BOOKLIBRARY"
echo "DB Admin User    : libadmin"
echo "DB Admin Password: Libadmin@345"
echo

