#!/bin/bash

yum install httpd -y >/dev/null 2>&1
systemctl enable httpd >/dev/null 2>&1
systemctl start httpd >/dev/null 2>&1
yum install mariadb -y >/dev/null 2>&1
echo
echo "Database server name to be entered for further configuration."
echo "If the database is in the same host then enter \"localhost\""
echo "If the databse is in a remote server then enter either the IP Address,"
echo "Host name, FQDN or DB end point of the remote server.."
echo
echo -n "Enter the DB Server name or IP Address:"
read dbserver

echo "#!/bin/bash" >code/app.config
echo " " >>code/app.config
echo "Version: 1.0" >>code/app.config
echo " " >>code/app.config
echo "database_host=${dbserver}" >>code/app.config
ping -c 3 ${dbserver} >/dev/null 2>&1
if [ $? -ne 0 ]
then
	echo "ERROR: Connect to DB server through ping test... Failed!"
	exit 10
fi
echo " " >>code/app.config
echo "database_name=BOOKLIBRARY" >>code/app.config
echo " " >>code/app.config
echo "database_user=libadmin" >>code/app.config
echo " " >>code/app.config
echo "database_password=Libadmin@345" >>code/app.config
echo " " >>code/app.config
echo " " >>code/app.config
echo "# database_host:" >>code/app.config
echo "#       localhost - If the database is in the same host of app server" >>code/app.config
echo "#                   IP Address, hostname, FQDN or End point of database server." >>code/app.config
echo " "

rm -rf /var/www/html/* >/dev/null 2>&1
rm -rf /var/www/cgi-bin/* >/dev/null 2>&1
mv code/app.config /var/www/cgi-bin/app.config >/dev/null 2>&1
#cp ./code/html/* /var/www/html/ >/dev/null 2>&1
cp ./code/html/index.html /var/www/html/index.html >/dev/null 2>&1
echo "<footer>" >>/var/www/html/index.html 
echo "  <p>Powerd by: `hostname`</p>" >>/var/www/html/index.html   
echo "</footer>" >>/var/www/html/index.html 
echo " " >>/var/www/html/index.html 
echo "</body>" >>/var/www/html/index.html 
echo "</html>" >>/var/www/html/index.html 
cp ./code/html/search.html /var/www/html/search.html >/dev/null 2>&1
echo "<footer>" >> /var/www/html/search.html 
echo "  <p>Powerd by: `hostname`</p>" >> /var/www/html/search.html 
echo "</footer>" >> /var/www/html/search.html 
echo " " >>/var/www/html/search.html 
echo "</body>" >> /var/www/html/search.html 
echo "</html>" >> /var/www/html/search.html 
cp ./code/cgi-bin/* /var/www/cgi-bin/ >/dev/null 2>&1
chown apache:apache /var/www/cgi-bin/* >/dev/null 2>&1
chown apache:apache /var/www/html/* >/dev/null 2>&1
chmod 700 /var/www/cgi-bin/* >/dev/null 2>&1
chmod 500 /var/www/cgi-bin/app.config >/dev/null 2>&1
cat httpd.conf >/etc/httpd/conf/httpd.conf 
systemctl restart httpd >/dev/null 2>&1

